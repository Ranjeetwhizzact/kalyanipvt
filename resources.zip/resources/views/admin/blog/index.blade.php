<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css">
    <title>Dashboard</title>
    <style>
        input:checked~div.sidebar {
            width: 50px;
        }

        input:checked~div.sidebar~div.main-content {
            margin-left: 50px;
        }

        input:checked~div>div>div img {
            display: none;
        }

        .sidebar {
            transition: width 0.3s ease;
        }

        .main-content {
            transition: margin-left 0.3s ease;
        }

        .dropdown-content {
            display: none;
        }

        /* Show dropdown when the parent div is focused */
        .dropdown:hover .dropdown-content,
        .dropdown:focus-within .dropdown-content {
            display: block;
        }

        @media (max-width: 640px) {
            .sidebar span {
                display: none;
            }
        }


        @media (min-width: 640px) {
            .sidebar span {
                display: inline;
            }
        }
    </style>
</head>

<body class="bg-gray-100">
    <div class="flex h-screen">
        <!-- Sidebar -->
        @include('admin.common.sidenav')
        @include('admin.common.toster')


        <!-- Main Content -->
        <div class="main-content flex-1 p-6 ml-64 transition-all duration-300">
            <!-- Welcome Section -->
            <div class="bg-white p-6 mb-4 rounded-lg shadow-md">
                <h2 class="text-2xl font-bold">Welcome, {{ auth()->user()->name ?? 'Guest' }}!</h2>
                <p class="text-gray-600 mt-2">Track and manage your product activi ties here.</p>
            </div>

            <!-- Table Section -->
            <div class="bg-white p-6 rounded-lg shadow-md">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-xl font-semibold">Blog Management</h3>
                    <a href="{{ url('/newblog') }}"
                        class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">Add Blog</a>
                </div>

                <!-- Responsive Table -->
                <div>
                    <table class="min-w-full bg-white border border-gray-200">
                        <thead>
                            <tr class="bg-gray-200 text-gray-700 text-left text-sm">
                                <th class="py-3 px-4 border-b">ID</th>
                                <th class="py-3 px-4 border-b">Name</th>
                                <th class="py-3 px-4 border-b table-cell">Image</th>
                                <th class="py-3 px-4 border-b table-cell">Short Description</th>

                                <th class="py-3 px-4 border-b">Status</th>
                                <th class="py-3 px-4 border-b">Actions</th>
                            </tr>

                        </thead>
                        <tbody>
                            @if ($blog->count() > 0)
                                @php
                                    $x = ($blog->currentPage() - 1) * $blog->perPage();
                                @endphp
                                @foreach ($blog as $item)
                                    @php $x++; @endphp
                                    <tr class="border-b hover:bg-gray-50">
                                        <td class="py-2 text-sm px-4">{{ $x }}</td>
                                        <td class="py-2 px-3">{{ $item->title }}</td>
                                        <td class="py-2 px-3 table-cell">
                                            <img src="{{ asset($item->featured_image) }}"
                                                class="h-10 w-10 rounded-full object-cover" alt="Product Image">
                                        </td>
                                        <td class="py-2 px-3 table-cell">
                                            <p class="line-clamp-3 h-18 overflow-hidden text-ellipsis">
                                                {{ \Illuminate\Support\Str::limit(strip_tags($item->content), 150) }}
                                            </p>
                                        </td>
                                        {{-- <td class="py-2 px-3 table-cell">{{ $item->discription }}</td> --}}
                                        <td class="py-2 px-3">{{ $item->is_active }}</td>
                                        <td class="py-2 px-3 flex space-x-2 relative">
                                            <!-- Dropdown Container -->
                                            <div class="relative group">
                                                <!-- Dropdown Button -->
                                                <button
                                                    class="inline-flex text-sm justify-between w-full rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white font-medium text-gray-700 hover:bg-gray-50">
                                                    Setting
                                                    <svg class="-mr-1 ml-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 20 20" fill="currentColor">
                                                        <path fill-rule="evenodd"
                                                            d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 011.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                                                            clip-rule="evenodd" />
                                                    </svg>
                                                </button>

                                                <!-- Dropdown Content -->
                                                <div
                                                    class="absolute z-50 right-0 mt-0 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 hidden group-hover:block hover:block">
                                                    <div class="py-1">

                                                        <a href="{{ url('editblog/' . encrypt($item->id)) }}"
                                                            class="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100">Edit</a>
                                                        <form action="{{ url('deleteblog/' . encrypt($item->id)) }}"
                                                            method="POST"
                                                            class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                                            onsubmit="return confirm('Are you sure you want to delete this product?');">
                                                            @csrf
                                                            <input type="submit"
                                                                class="cursor-pointer w-full text-start" value="Delete">
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>

                                    </tr>
                                @endforeach
                            @else
                                <tr>
                                    <td colspan="7" class="py-4 text-center text-gray-500">No categories found.</td>
                                </tr>
                            @endif
                        </tbody>

                    </table>
                    <div class="mt-4">
                        {{ $blog->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
